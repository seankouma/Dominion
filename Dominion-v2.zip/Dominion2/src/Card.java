import java.util.*;

import javax.xml.soap.Node;

import java.io.File;
import java.io.FileNotFoundException;

public class Card {
	String name;
	int numCards;
	int cost;
	char id;
	Card next;
	int forShuffle;
	
	public Card clone(Gameplay game) {
		return null;
	}
		
	}
