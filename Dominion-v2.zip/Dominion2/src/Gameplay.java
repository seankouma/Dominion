/* Sean Kouma
 * Phil Sharp
 * Computer Science II
 * 23 February 2019
 */

import java.util.*;
import java.io.*;
import java.io.FileNotFoundException;

public class Gameplay {
	
	public CardList vCards = new CardList();
	public CardList tCards = new CardList();
	public CardList aCards = new CardList();
	public  CardList allCards = new CardList();
	public  Scanner keyboard = new Scanner(System.in);
	 char id = 'A';
	int forShuffle = 0;
	 Player one;
	 Player two;
	
	public static void main(String[] args) {
		
		Gameplay currentGame = new Gameplay();

		try {
			// Reads the text file into a File object.
			File file1 = new File("C:\\Users\\chess\\Downloads\\cards_1.txt");
			// Creates a scanner object so it's easy to print out the data.
			Scanner input = new Scanner(file1);
			currentGame.storeCards(input);
		} catch (FileNotFoundException e) {
			System.out.println("The file could not be found, sad day.");
		} catch(Exception e) {
			System.out.println("Hmm, that's weird, it threw a weird exception.");
		}
		
		currentGame.one = currentGame.makePlayer(); // Creates the players
		currentGame.two = currentGame.makePlayer();
		
		currentGame.runGame();
	}
	// Stores the cards in an CardList.	
	public  void storeCards(Scanner a) {
			String temp = a.nextLine();
			int cur = 0;
			int cur1 = 0;
			int cur2 = 0;
			
			while (temp.equals("victory") || temp.equals("Treasure") || temp.equals("Action")) {
				if (temp.equals("victory")) {
					allCards.add(new Victory(a.nextLine().trim(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextLine(), id, forShuffle));
					vCards.add((allCards.returnLast()).clone(this));
					a.nextLine();
					temp = a.nextLine().trim();
					id++;
					cur++;
					forShuffle++;
				}
				else if (temp.equals("Treasure")) {
					allCards.add(new Treasure(a.nextLine().trim(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextLine(), id, forShuffle));
					tCards.add((allCards.returnLast()).clone(this));
					a.nextLine();
					temp = a.nextLine().trim();
					id++;
					cur1++;
					forShuffle++;
				}
				else if (temp.equals("Action")) {
					allCards.add(new Action(a.nextLine().trim(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextInt(), a.nextLine(), id, forShuffle));
					aCards.add((allCards.returnLast()).clone(this));
					a.nextLine();
					temp = a.nextLine().trim();
					id++;
					cur2++;
					forShuffle++;
				}
			}
	}
		
		public static void displayCards1(Card current) {
			System.out.println();
				CardPrinter.printHorizontalBorder();
				CardPrinter.printLine(current.name);
				CardPrinter.printLine("Type: " + current.getClass().getName());
				CardPrinter.printLine("Cost", current.cost);
					Action temp = (Action) current;
					CardPrinter.printLine("Worth", temp.worth);
					CardPrinter.printLine("Add Cards" , temp.addc);
					CardPrinter.printLine("Add Actions" , temp.adda);
					CardPrinter.printLine("Add Buy" , temp.addb);
				CardPrinter.printLine("ID Number" , current.id);
				CardPrinter.printHorizontalBorder();
			
		}
		public Player makePlayer() {
			System.out.println("Hello player, what would you like your player name to be: ");
			return new Player(keyboard.next(), this);
		}
		
		public void runGame() {
			while (isGameOver(this) == false) {
				one.playerTurn();
				if (isGameOver(this) == false) {
					two.playerTurn();
				}
			}
		}
		
		public static boolean isGameOver(Gameplay game) {
			Card current = game.allCards.head;
			int emptyPiles = 0;
			while (current != null) {
				if (current.numCards == 0) {
					emptyPiles++;
				}
				current = current.next;
			}
			
			return (emptyPiles > 2);
		}
		
		public static Player gameWinner(Gameplay game) {
			int p1VP = 0;
			int p2VP = 0;
			// Checking player one's victory points
			Card current = game.one.discard.head;
			while (current != null) {
				game.one.discard.moveFirst(game.one.deck);
				current = current.next;
			}
			current = game.one.deck.head;
			while (current != null) {
				if (current.getClass().getName().equals("Victory")){
					Victory temp  = (Victory) current;
					p1VP += temp.vp;
				}
				current = current.next;
			}
			// Checking Player two's victory points
			current = game.two.discard.head;
			while (current != null) {
				game.two.discard.moveFirst(game.one.deck);
				current = current.next;
			}
			current = game.two.deck.head;
			while (current != null) {
				if (current.getClass().getName().equals("Victory")){
					Victory temp  = (Victory) current;
					p2VP += temp.vp;
				}
				current = current.next;
			}
			
			if (p1VP > p2VP) {
				return game.one;
			}
			if (p1VP < p2VP) {
				return game.two;
			}
			else {
				return null;
			}
			
		}

}
